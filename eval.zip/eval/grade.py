from datasets import load_dataset
import argparse
import os
import itertools
import numpy as np
from tqdm import tqdm
import json
from typing import List, Union
import sys
sys.path.append("/projects/extern/kisski/kisski-spath/dir.project/Peft-RLVR")
from verl.utils.reward_score.deepscaler import rllm_reward_fn_math

def estimate_pass_at_k(
    num_samples: Union[int, List[int], np.ndarray],
    num_correct: Union[List[int], np.ndarray],
    k: int
) -> np.ndarray:
    """
    Estimates pass@k of each problem and returns them in an array.
    """

    def estimator(n: int, c: int, k: int) -> float:
        """
        Calculates 1 - comb(n - c, k) / comb(n, k).
        """
        if n - c < k:
            return 1.0
        return 1.0 - np.prod(1.0 - k / np.arange(n - c + 1, n + 1))

    if isinstance(num_samples, int):
        num_samples_it = itertools.repeat(num_samples, len(num_correct))
    else:
        assert len(num_samples) == len(num_correct)
        num_samples_it = iter(num_samples)

    return np.array([estimator(int(n), int(c), k) for n, c in zip(num_samples_it, num_correct)])


def process_jsonl_file(file_name):
    """
    Process a JSONL file and dynamically handle the number of problems.
    """
    results = []
    with open(file_name) as f:
        for line in f:
            data = json.loads(line)
            id = int(data["example_id"])
            while len(results) <= id:  # Ensure the list is large enough
                results.append({"gt": None, "responses": [], "prompt": None})
            gt = data["answer"]
            response = data["response"]
            prompt = data['prompt']
            results[id]["gt"] = gt
            results[id]["prompt"] = prompt
            results[id]["responses"].append(response)
    return results


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str)
    parser.add_argument("--step", type=int)
    parser.add_argument("-b", "--benchmark", type=str, default="Math-500")
    args = parser.parse_args()

    benchmark_dict = {
        "Math-500": {
            "n": 192,
        },
        "AIME24": {
            "n": 1280,
        },
        "AIME25": {
            "n": 1280,
        },
        "Minerva": {
            "n": 192,
        },
        "Olympiad-Bench": {
            "n": 192,
        },
    }

    file_path = f"gen_outputs/Qwen2.5-3B-Instruct/step{args.step}/{args.model_name}/{args.benchmark.lower()}_t0.6_p0.95_n{benchmark_dict[args.benchmark]['n']}-MNT4096.jsonl"
    df = process_jsonl_file(file_path)
    tqdm_loader = tqdm(range(len(df)))
    total = []
    correct = []
    
    for i in tqdm_loader:
        prompt = df[i]['prompt']
        responses = df[i]['responses']
        gt = df[i]['gt']
        all_scores = []

        for i, resp in enumerate(responses):
            score = rllm_reward_fn_math("", resp, gt)
            all_scores.append(score)

        total.append(len(responses))
        correct.append(sum(all_scores))
        tqdm_loader.set_postfix(acc=np.mean(all_scores).item())
        # if len(all_convs) == 0:
        #     correct.append(0)
        #     prm_scores = [0]
        # else:
        
    
    output_dir = f"eval_results/{args.model_name}"
    os.makedirs(output_dir, exist_ok=True)

    json_path = os.path.join(output_dir, 'pass.jsonl')
    row_data = {
        'model_name': args.model_name,
        "step": args.step,
        'dataset': args.benchmark,
        'raw_scores': correct,
        'total': total[0],
    }

    ks = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
    total = np.array(total)
    correct = np.array(correct)
    pass_at_k = {f"pass@{k}": estimate_pass_at_k(total, correct, k).mean().item()
                for k in ks if (total >= k).all()}
    print(pass_at_k)
    for k, v in pass_at_k.items():
        row_data[k] = v
    print("JSON path:", json_path)
    # Write to CSV
    with open(json_path, 'a+') as f:
        json.dump(row_data, f)
        f.write('\n')
    